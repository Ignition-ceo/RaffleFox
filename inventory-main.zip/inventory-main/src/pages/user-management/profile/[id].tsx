import React from "react";
import UserProfile from "../../../components/user/profile";

const UserProfilePage: React.FC = () => {
  return <UserProfile />;
};

export default UserProfilePage; 